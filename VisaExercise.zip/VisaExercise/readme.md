Please run script via terminal using following command once in the folder location:

> python generateCalendar.py [[year (YYYY format)] [month (MM Format)]]

* Posting year and month input variables will overwrite the calendar year/month returned.
* Current implementation requires either both or none of the two to be set.
* The current date will not be highlighted if the year/month is does not match the current year/month.
